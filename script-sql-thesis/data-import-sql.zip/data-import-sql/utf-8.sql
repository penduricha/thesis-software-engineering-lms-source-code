-- set utf-8 cho các bảng sau
alter table bank_test_case_java_core convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table question_java_core_exam convert to character set utf8mb4 collate utf8mb4_unicode_ci;
alter table bank_question_java_core convert to character set utf8mb4 collate utf8mb4_unicode_ci;