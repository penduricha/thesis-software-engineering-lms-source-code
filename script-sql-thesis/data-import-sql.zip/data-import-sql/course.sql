INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (1, 'DHKTPM20ATT', 'Object-oriented programming', 2026, 1, 2025);
INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (2, 'DHKTPM20BTT', 'Object-oriented programming', 2026, 1, 2025);
INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (3, 'DHHTTT20ATT', 'Object-oriented programming', 2026, 1, 2025);
INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (4, 'DHHTTT20BTT', 'Object-oriented programming', 2026, 1, 2025);
INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (5, 'DHKTPM20A', 'Object-oriented programming', 2026, 1, 2025);
INSERT INTO project_thesis_final.course (course_id, class_name, course_name, end_year, semester, start_year) VALUES (6, 'DHKTPM20B', 'Object-oriented programming', 2026, 1, 2025);
