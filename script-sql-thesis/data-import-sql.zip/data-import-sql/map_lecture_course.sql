insert map_lecture_course (lecture_id, course_id) value (01120009, 1);
insert map_lecture_course (lecture_id, course_id) value (01120013, 3);
insert map_lecture_course (lecture_id, course_id) value (01120013, 4);
insert map_lecture_course (lecture_id, course_id) value (01120050, 2);
insert map_lecture_course (lecture_id, course_id) value (01120050, 5);
insert map_lecture_course (lecture_id, course_id) value (01120050, 6);
